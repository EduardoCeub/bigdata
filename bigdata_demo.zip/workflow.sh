#!/bin/bash

# Baixar dados: Download data, upload to HDFS, run Spark job

# Passo 1: Baixar dados (localmente ou via contêiner)
wget -O yellow_tripdata_2015-01.csv https://d37ci6vzurychx.cloudfront.net/trip-data/yellow_tripdata_2023-01.parquet  # Note: It's parquet, but we treat as CSV for simplicity; adjust if needed

# Etapa 2: Enviar para o HDFS (executar no contêiner hadoop-master)
docker exec -it hadoop-master hdfs dfs -mkdir /data
docker exec -it hadoop-master hdfs dfs -put yellow_tripdata_2015-01.csv /data/

# Passo 3: executar spark job
docker exec -it spark-master spark-submit --master spark://spark-master:7077 /app/analyze_taxi.py

# Passo 4: visualizar no Jupyter