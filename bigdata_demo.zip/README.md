# Instruções de Execução Reproduzíveis

## Pré-requisitos
- Docker e Docker Compose instalados.
- Pelo menos 4GB de RAM disponíveis.

## Passos para Levantar o Projeto
1. Clone ou extraia este repositório/diretório.
2. No terminal, navegue para o diretório raiz (onde está docker-compose.yml).
3. Execute: `docker-compose up -d` (levanta os containers: Hadoop, Spark, Jupyter).
4. Aguarde ~2-5 minutos para inicialização.
5. Acesse UIs para verificação:
   - HDFS: http://localhost:9870
   - Spark Master: http://localhost:8080
   - Jupyter: http://localhost:8888 (token no log do container: `docker logs jupyter`).
6. Baixe os dados usando o link em link.txt e execute o workflow.sh:
   - `bash workflow.sh`
7. Para visualização: No Jupyter, crie um notebook, importe o Parquet de HDFS e gere plots (ou rode o código em analyze_taxi.py diretamente).
8. Para parar: `docker-compose down`.

## Notas
- Se o dataset for muito grande, escale workers no docker-compose.
- Isso é executável em qualquer ambiente com Docker (Linux, Mac, Windows com WSL).